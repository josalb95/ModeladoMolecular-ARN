#!/bin/bash
#
#SBATCH -p eck-q
#SBATCH --chdir=/home/alumno03/Working-directory/practica-arn/5-extra
#SBATCH -J runextra
#SBATCH --cpus-per-task=1

date
gmx mdrun -deffnm arn -c arn.g96 -nt 1
date



